<html>
<head>
   <meta charset="utf-8">
   <title>Investment Form</title>
   <style type="text/css">
     #central
	 {
	 border-radius:15px; 
	  
	  }
  </style>

</head>
<body>
                   <div id="central">
                <form method="post" action="invest.php">
                      <p><label>Initiator:</label><input type="text"style="margin-left:120px;" name="initiator" id="i_name"></p>
					  <p><label>Date of Investment</label><input type="date"style="margin-left:40px;" name="date" id="i_name"></p>
					  <p><label>Initial Capital required:</label><input type="number" style="margin-left:10px;" name="capital" id="capital"></p>
					  <p><label>Profits</label><input type="text" name="profits" style="margin-left:120px;" id="profits"></p>
					  <p><label>Losses</label><input type="text" name="losses" style="margin-left:120px;" id="losses">
					  <p><input type="submit" value="submit"></p>
					  </div>
					  
                 </form>

</body>









</html>
