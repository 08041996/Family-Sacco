<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SACCO SYSTEM</title>
<link rel="stylesheet" type="text/css" href="extra.css"/>
<link rel="stylesheet" type="text/css" href="bootstrap.css"/>
<script type="text/javascript" src="jquery-3.2.1-1.js"> </script>
<script type="text/javascript" src="bootstrap.js"> </script>
</head>
<body>
<nav class= "navbar navbar-inverse">
<div class="container-fluid">

<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a href="#" class="navbar-brand">FAMILY SACCO</a>
</div>

<div class="collapse navbar-collapse" id="main">
<ul class="nav navbar-nav"> 
<li class="active"> <a href="home.php">HOME</a> </li>

<li class="dropdown" >
<a href="#"class="dropdown-toggle" data-toggle="dropdown" >CONTRIBUTIONS <span class="caret"></span></a>
<ul class= "dropdown-menu">
<li><a href="#">Submit contribution</a></li>
<li><a href="#">Check contribution</a></li>
</ul>
</li>

<li class="dropdown" >
<a href="#"class="dropdown-toggle" data-toggle="dropdown">LOANS <span class="caret"></span></a>
<ul class= "dropdown-menu">
<li><a href="#">Loan Request</a></li>
<li><a href="#">Check loan Status</a></li>
</ul>
</li>

<li class="dropdown" >
<a href="#"class="dropdown-toggle" data-toggle="dropdown" >IDEA/INVESTMENT <span class="caret"></span></a>
<ul class= "dropdown-menu">
<li><a href="#">Submit Idea</a></li>
<li><a href="#">Confirm Idea</a></li>
</ul>
</li>

<li><a href="reports.php">REPORTS</a></li>
<div class="nav navbar-nav navbar-right">
<li><a href="logout.php"class="pull-right"> <strong>logout</strong></a>
</div>
</ul>



</div>

</nav>

</div>

</body>
<h1  class="page-header">SUBMIT BUSSINESS PROPOSAL<small>   Please fill the idea submit form</small></h1><br/><br/>
<form>
<div class="form-group">
BUSINESS INITIATOR:<br/>
<label> LAST NAME:</label>&nbsp;&nbsp;<input type="text" name="lastname" class="form-control"/>
</div>










</html>