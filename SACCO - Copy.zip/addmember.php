<html>
<head>
   <meta charset="utf-8">
   <title>Investment Form</title>
   <style type="text/css">
     #central
	 {
	 border-radius:15px; 
	  
	  }
  </style>

</head>
<body>
                   <div id="central">
                <form method="post" action="addmem.php">
                      <p><label>First Name:</label><input type="text"style="margin-left:120px;" name="fname" id="i_name"></p>
					  <p><label>Last Name</label><input type="text"style="margin-left:40px;" name="lname" id="i_name"></p>
					  <p><label>Email</label><input type="text" style="margin-left:10px;" name="email" id="capital"></p>
					  <p><label>Username</label><input type="text" name="username" style="margin-left:120px;" id="profits"></p>
					  <p><label>Contact</label><input type="text" name="contact" style="margin-left:120px;" id="losses">
					  <p><label>password</label><input type="password" name="password" style="margin-left:120px;" id="losses">
					  <p><label>Initial Contribution</label><input type="text" name="contribution" style="margin-left:120px;" id="losses">
					  <p><input type="submit" value="submit"></p>
					  </div>
					  
                 </form>

</body>
</html>
